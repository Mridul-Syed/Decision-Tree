from __future__ import print_function
import math 


list = [["36-55","MS","High","S","yes"],["18-35","HS","Low","S","no"],["36-55","MS","Low","S","yes"],["18-35","BS","High","S","no"],["<18","HS","Low","S","yes"],
        ["18-35","BS","High","M","no"],["36-55","BS","Low","M","no"],[">55","BS","High","S","yes"],["36-55","MS","Low","M","no"],[">55","MS","High","M","yes"],
        ["<18","HS","High","S","no"],["36-55","MS","Low","S","yes"],["36-55","HS","Low","S","yes"],["<18","HS","Low","M","yes"],["18-35","BS","High","M","no"],
        [">55","HS","High","M","yes"],[">55","BS","Low","S","yes"],["36-55","HS","High","M","no"],["36-55","MS","High","S","yes"],[">55","MS","High","S","yes"]]

HBC = 0
HBC_AGE = 0
HBC_EDU = 0
HBC_INCOME = 0
HBC_MARRI = 0

def entropy_BC() :
    i = 0
    y = 0
    n = 0
    while i<20 :
        if list[i][4] == "yes" :
            y+=1
        else:
            n+=1
        i+=1
    
    pyes = y/20
    pno = n/20
    HBC = - ( pyes*math.log2(pyes) + pno*math.log2(pno) )
    
    print("Entropy of Class = ", HBC)
    print("\n")
    
    return HBC

def entropy_AGE() :
    i = 0 
    c1y = 0
    c2y = 0
    c3y = 0
    c4y = 0
    c1n = 0
    c2n = 0
    c3n = 0
    c4n = 0
    while i<20 :
        if list[i][0] == "<18" and list[i][4] == "yes"  :
            c1y+=1
        if list[i][0] == "<18" and list[i][4] == "no"  :
            c1n+=1
        if list[i][0] == "18-35" and list[i][4] == "yes"  :
            c2y+=1
        if list[i][0] == "18-35" and list[i][4] == "no"  :
            c2n+=1
        if list[i][0] == "36-55" and list[i][4] == "yes"  :
            c3y+=1
        if list[i][0] == "36-55" and list[i][4] == "no"  :
            c3n+=1
        if list[i][0] == ">55" and list[i][4] == "yes"  :
            c4y+=1
        if list[i][0] == ">55" and list[i][4] == "no"  :
            c4n+=1
        i+=1
        
    yes1 = (c1y)/(c1y+c1n)
    no1 = (c1n)/(c1y+c1n)
    HBC_AGE_C1 = -( yes1*math.log2(yes1) + no1*math.log2(no1) )
    yes2 = (c2y)/(c2y+c2n)
    no2 = (c2n)/(c2y+c2n)
    if yes2 == 1 or no2 == 1 :
        HBC_AGE_C2 = 0
    yes3 = (c3y)/(c3y+c3n)
    no3 = (c3n)/(c3y+c3n)
    HBC_AGE_C3 = -( yes3*math.log2(yes3) + no3*math.log2(no3) )
    yes4 = (c4y)/(c4y+c4n)
    no4 = (c4n)/(c4y+c4n)
    if yes4 == 1 or no4 == 1 :
        HBC_AGE_C4 = 0
    print("Entropy_AGE_C1 = ",HBC_AGE_C1) #<18
    print("Entropy_AGE_C2 = ",HBC_AGE_C2) #18-35
    print("Entropy_AGE_C3 = ",HBC_AGE_C3) #36-55
    print("Entropy_AGE_C4 = ",HBC_AGE_C4) #>55
    HBC_AGE = ((c1y+c1n)/20)*HBC_AGE_C1 + ((c3y+c3n)/20)*HBC_AGE_C3
    print("Entropy AGE = ",HBC_AGE)
    print('\n')
    
    return HBC_AGE
                 
def entropy_EDU() :
    i = 0 
    c1y = 0
    c2y = 0
    c3y = 0
    c1n = 0
    c2n = 0
    c3n = 0
    while i<20 :
        if list[i][1] == "HS" and list[i][4] == "yes"  :
            c1y+=1
        if list[i][1] == "HS" and list[i][4] == "no"  :
            c1n+=1
        if list[i][1] == "BS" and list[i][4] == "yes"  :
            c2y+=1
        if list[i][1] == "BS" and list[i][4] == "no"  :
            c2n+=1
        if list[i][1] == "MS" and list[i][4] == "yes"  :
            c3y+=1
        if list[i][1] == "MS" and list[i][4] == "no"  :
            c3n+=1
        i+=1
    yes1 = (c1y)/(c1y+c1n)
    no1 = (c1n)/(c1y+c1n)
    HBC_EDU_C1 = -( yes1*math.log2(yes1) + no1*math.log2(no1) )
    yes2 = (c2y)/(c2y+c2n)
    no2 = (c2n)/(c2y+c2n)
    HBC_EDU_C2 = -( yes2*math.log2(yes2) + no2*math.log2(no2) ) 
    yes3 = (c3y)/(c3y+c3n)
    no3 = (c3n)/(c3y+c3n)
    HBC_EDU_C3 = -( yes3*math.log2(yes3) + no3*math.log2(no3) )
    
    print("Entropy_EDU_C1 = ",HBC_EDU_C1) #HS
    print("Entropy_EDU_C2 = ",HBC_EDU_C2) #BS
    print("Entropy_EDU_C3 = ",HBC_EDU_C3) #MS
    
    HBC_EDU = ((c1y+c1n)/20)*HBC_EDU_C1 + ((c2y+c2n)/20)*HBC_EDU_C2 + ((c3y+c3n)/20)*HBC_EDU_C3
    print("Entropy_EDU = ",HBC_EDU)
    print('\n')
    
    return HBC_EDU

def entropy_INCOME() :
    i = 0 
    c1y = 0
    c2y = 0
    c1n = 0
    c2n = 0
    while i<20 :
        if list[i][2] == "High" and list[i][4] == "yes"  :
            c1y+=1
        if list[i][2] == "High" and list[i][4] == "no"  :
            c1n+=1
        if list[i][2] == "Low" and list[i][4] == "yes"  :
            c2y+=1
        if list[i][2] == "Low" and list[i][4] == "no"  :
            c2n+=1
        i+=1
        
    yes1 = (c1y)/(c1y+c1n)
    no1 = (c1n)/(c1y+c1n)
    HBC_INCOME_C1 = -( yes1*math.log2(yes1) + no1*math.log2(no1) )
    yes2 = (c2y)/(c2y+c2n)
    no2 = (c2n)/(c2y+c2n)
    HBC_INCOME_C2 = -( yes2*math.log2(yes2) + no2*math.log2(no2) ) 
    
    print("Entropy_INCOME_C1 = ",HBC_INCOME_C1) #High
    print("Entropy_INCOME_C2 = ",HBC_INCOME_C2) #Low
   
    
    HBC_INCOME = ((c1y+c1n)/20)*HBC_INCOME_C1 + ((c2y+c2n)/20)*HBC_INCOME_C2 
    print("Entropy_INCOME = ",HBC_INCOME)
    print('\n')
    
    return HBC_INCOME

def entropy_MARRI() :
    i = 0 
    c1y = 0
    c2y = 0
    c1n = 0
    c2n = 0
    while i<20 :
        if list[i][3] == "S" and list[i][4] == "yes"  :
            c1y+=1
        if list[i][3] == "S" and list[i][4] == "no"  :
            c1n+=1
        if list[i][3] == "M" and list[i][4] == "yes"  :
            c2y+=1
        if list[i][3] == "M" and list[i][4] == "no"  :
            c2n+=1
        i+=1
        
    yes1 = (c1y)/(c1y+c1n)
    no1 = (c1n)/(c1y+c1n)
    HBC_MARRI_C1 = -( yes1*math.log2(yes1) + no1*math.log2(no1) )
    yes2 = (c2y)/(c2y+c2n)
    no2 = (c2n)/(c2y+c2n)
    HBC_MARRI_C2 = -( yes2*math.log2(yes2) + no2*math.log2(no2) ) 
    
    print("Entropy_MARRI_C1 = ",HBC_MARRI_C1) #S
    print("Entropy_MARRI_C2 = ",HBC_MARRI_C2) #M
   
    
    HBC_MARRI = ((c1y+c1n)/20)*HBC_MARRI_C1 + ((c2y+c2n)/20)*HBC_MARRI_C2 
    print("Entropy_MARRITAL_STATUS = ",HBC_MARRI)
    print('\n')
    
    return HBC_MARRI

def MAIN():
    HBC = entropy_BC()
    HBC_AGE = entropy_AGE()
    HBC_EDU = entropy_EDU()
    HBC_INCOME = entropy_INCOME()
    HBC_MARRI = entropy_MARRI()
    GAIN_AGE = HBC- HBC_AGE
    GAIN_EDU = HBC - HBC_EDU
    GAIN_INCOME = HBC - HBC_INCOME
    GAIN_MARRI = HBC - HBC_MARRI
    
    MAX_GAIN = max(GAIN_AGE, GAIN_EDU,GAIN_INCOME,GAIN_MARRI)
    print(MAX_GAIN)
MAIN()



from anytree import Node, RenderTree

age = Node("Age")
Age_L_18 =Node("Age <18)",parent = age)
Age_18_35 =Node("Age 18-35)",parent = age)
Age_36_55 =Node("Age 36-55)",parent = age)
Age_G_55 =Node("Age >55)",parent = age)


print(age)

for pre,fill,node in RenderTree(age):
    print("%s%s" %(pre,node.name))