#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 13:53:36 2020

@author: tanzid
"""
from anytree import Node, RenderTree
import numpy as np
import pandas as pd
import math


def using_entro(bc):
    bc_index = list(bc.columns)
    row_len = len(bc)
    col_len = len(bc_index)
    unique_data_number = list(bc.nunique())
    unique_data = np.zeros((col_len,max(unique_data_number)))
    unique_data_store = np.empty((col_len,max(unique_data_number)), dtype=object)
    
    i=0
    while(i<col_len):
        j=0
        num_of_uni_data=1
        srl_of_uni_data=0
        bc2 = bc.sort_values(by = bc_index[i])
        data_ar = bc2.values
        data_a = np.empty(col_len,dtype=object)
        data_arr = np.append(data_ar, [data_a],axis=0)
        while(j<row_len):
            if(data_arr[j][i] == data_arr[j+1][i]):
                num_of_uni_data = num_of_uni_data + 1
            else:
                unique_data_store[i][srl_of_uni_data]=data_arr[j][i]
                unique_data[i][srl_of_uni_data] = num_of_uni_data
                srl_of_uni_data = srl_of_uni_data + 1
                num_of_uni_data=1
            j = j+1
        i = i+1
    
    probability_of_unique_data = np.zeros((col_len,max(unique_data_number)))
    
    i=0
    while(i<col_len):
        j=0
        while(j<unique_data_number[i]):
            probability_of_unique_data[i][j]=unique_data[i][j]/row_len
            j=j+1
        i=i+1
        
    ent_of_data = np.zeros((col_len-1,max(unique_data_number),unique_data_number[col_len-1]))
    
    i=0
    unique_data1 = np.append(unique_data, unique_data,axis=1)
    while(i<col_len-1):
        j=0
        a=0
        b=int(unique_data[i][0])
        while(j<unique_data_number[i]):
            bc3 = bc.sort_values(by = bc_index[i]).iloc[a:b,col_len-1].sort_values()
            a=a+int(unique_data1[i][j])
            b=b+int(unique_data1[i][j+1])
            data_ar1 = bc3.values
            data_arr1 = np.append(data_ar1, ['Exit'],axis=0)
            k=0
            num_of_uni_data = 1
            srl_of_uni_data = 0
            while(k<unique_data[i][j]):
                if(data_arr1[k] == data_arr1[k+1]):
                    num_of_uni_data = num_of_uni_data + 1
                else:
                    ent_of_data[i][j][srl_of_uni_data] = num_of_uni_data
                    srl_of_uni_data = srl_of_uni_data + 1
                    num_of_uni_data=1
                k=k+1
            j=j+1
        i=i+1
    
    
    entropy_of_data = np.zeros((col_len-1,max(unique_data_number)))
    
    
    i=0
    while(i<col_len-1):
        j=0
        while(j<unique_data_number[i]):
            k=0
            total=0
            while(k<unique_data_number[col_len-1]):
                total = total + (-((ent_of_data[i][j][k]/unique_data[i][j])*math.log((ent_of_data[i][j][k]/unique_data[i][j]),2)))
                if(total == 0):
                    break
                k=k+1
            entropy_of_data[i][j]=total
            j=j+1
        i=i+1
    
    
    entropy_of_attribute = np.zeros(col_len-1)
    
    i=0
    while(i<col_len-1):
        j=0
        total=0
        while(j<unique_data_number[i]):
            total=total+(probability_of_unique_data[i][j]*entropy_of_data[i][j])
            j=j+1
        entropy_of_attribute[i]=total
        i=i+1
    
    entropy_of_class = 0
    
    i=0
    while(i<unique_data_number[col_len-1]):
        entropy_of_class = entropy_of_class + (-(unique_data[col_len-1][i]/row_len)*math.log((unique_data[col_len-1][i]/row_len),2))
        i=i+1
    
    info_gain = list(np.zeros(col_len-1))
    
    i=0
    while(i<col_len-1):
        info_gain[i] = entropy_of_class - entropy_of_attribute[i]
        i=i+1
        
    
    return info_gain, bc_index, unique_data_number, unique_data_store, unique_data, entropy_of_data, row_len, col_len



def exiting_tree_representation(data_file, dictionary, paren, in_ga, bc_in, uni_da_num, uni_da_sto, uni_da, en_of_da, ro_l, co_l):
    if(len(in_ga)==0):
        return dictionary
    ma_in_ga_in = in_ga.index(max(in_ga))
    ma_in_ga = bc_in[ma_in_ga_in]
    dictionary[ma_in_ga] = Node(ma_in_ga, parent=dictionary[paren])
    s=0
    i=0
    while(i<uni_da_num[ma_in_ga_in]):
        dictionary[uni_da_sto[ma_in_ga_in][i]]=Node(uni_da_sto[ma_in_ga_in][i], parent=dictionary[ma_in_ga])
        if(en_of_da[ma_in_ga_in][i]==0):
            res_col = list(data_file.sort_values(by = bc_in[ma_in_ga_in]).iloc[0:ro_l,co_l-1])
            dictionary[res_col[s]]=Node(res_col[s], parent=dictionary[uni_da_sto[ma_in_ga_in][i]])
        else:
            new_pc = data_file[data_file[ma_in_ga]==uni_da_sto[ma_in_ga_in][i]] 
            new_pc = new_pc.drop(columns=ma_in_ga)
            i_g, b_i, u_d_n, u_d_s, u_d, e_o_d, r_l, c_l = using_entro(new_pc)
            dictionary = exiting_tree_representation(new_pc, dictionary, uni_da_sto[ma_in_ga_in][i], i_g, b_i, u_d_n, u_d_s, u_d, e_o_d, r_l, c_l)
        s=int(s+uni_da[ma_in_ga_in][i])
        i=i+1
    return dictionary


def tree_presentation(pc, d,  max_info_gain, max_info_gain_index, uni_data, uni_data_num, uni_data_sto, ent_data, pc_index, r_len, c_len):
    d[max_info_gain] = Node(max_info_gain)
    s=0
    i=0
    while(i<uni_data_num[max_info_gain_index]):
        d[uni_data_sto[max_info_gain_index][i]]=Node(uni_data_sto[max_info_gain_index][i], parent=d[max_info_gain])
        if(ent_data[max_info_gain_index][i]==0):
            res_col = list(pc.sort_values(by = pc_index[max_info_gain_index]).iloc[0:r_len,c_len-1])
            d[res_col[s]]=Node(res_col[s], parent=d[uni_data_sto[max_info_gain_index][i]])
        else:
            new_pc = pc[pc[max_info_gain]==uni_data_sto[max_info_gain_index][i]] 
            new_pc = new_pc.drop(columns=max_info_gain)
            i_g, b_i, u_d_n, u_d_s, u_d, e_o_d, r_l, c_l = using_entro(new_pc)
            d = exiting_tree_representation(new_pc, d, uni_data_sto[max_info_gain_index][i], i_g, b_i, u_d_n, u_d_s, u_d, e_o_d, r_l, c_l)
        s=int(s+uni_data[max_info_gain_index][i])
        i=i+1
    return d

def main(): 
    csvf = pd.read_csv("F:\Dataset.csv")
    print(csvf)
    gain, csvf_index, csvf_uni_data_num, csvf_uni_data_sto, csvf_uni_data, csvf_ent_data, csvf_r_len, csvf_c_len = using_entro(csvf)
    
    root_info_gain_index = gain.index(max(gain))
    root_info_gain = csvf_index[root_info_gain_index]
    diction={}
    
    diction = tree_presentation(csvf, diction, root_info_gain, root_info_gain_index, csvf_uni_data, csvf_uni_data_num, csvf_uni_data_sto, csvf_ent_data, csvf_index, csvf_r_len, csvf_c_len)
    
    print("Decision Tree : ")
    for pre, _, node in RenderTree(diction[root_info_gain]):
         print("%s%s" % (pre, node.name))
    
# Calling main function 
if __name__=="__main__": 
    main() 